---
title: "Cafe con Leche So Smooth You'll Make Two: My Go-To Method"
meta: "Learn how to make a cafe con leche so smooth you'll make two. I share my exact brew ratio, milk temperature, and technique for a velvety cup every time."
category: "Coffee Recipes"
author: "HenrikSorensen."
image: "https://asipofcoffe.com/wp-content/uploads/2026/08/cafe-con-leche-so-smooth-you-ll-make-two.webp"
pubDate: "2026-08-12T07:37:33Z"
---

<p>There's a moment when the first sip of cafe con leche hits just right. The coffee is bold but not bitter. The milk is warm and creamy, not scorched. It's a balance that feels effortless—but getting there takes a few intentional choices.</p>
<figure><img src="https://cdn.midjourney.com/69319dc1-6c0e-43e6-b06b-80f3eb5d7024/0_2.png" alt="Pouring steamed milk into espresso for cafe con leche" /></figure>
<p>I've made this drink countless times, and I've settled on a method that delivers a consistently smooth cup. No fancy equipment required, just attention to a few key details.</p><h2>The Ratio That Works Every Time</h2><p>The most common mistake I see is a coffee-to-milk ratio that's off. Too much milk and you lose the coffee character. Too little and it's harsh. I stick with a 1:3 ratio: one part coffee to three parts milk. For a standard serving, that's a double shot of espresso (about 2 ounces) to 6 ounces of milk. This gives the coffee room to shine without overwhelming the palate.</p><p>If you're using a Moka pot, brew a concentrated batch—use a 1:2 coffee-to-water ratio and stop the brew as soon as it starts to gurgle. That prevents the bitter compounds from the end of the cycle from ruining the cup.</p><h2>Milk Temperature Is Everything</h2><p>I heat my milk to 150°F (65°C). That's the sweet spot. Below 140°F and it feels thin. Above 160°F and it starts to scald, which creates a cooked, flat taste and can make the proteins break down. Use a thermometer until you can gauge it by feel. The milk should be hot to the touch but not painful—think the temperature of a comfortable bath.</p><p>When frothing, I aim for microfoam: tiny, uniform bubbles that integrate into the milk rather than sitting on top. To achieve this, I position the steam wand just below the surface of the milk, slightly off-center, creating a whirlpool. This incorporates air gradually and breaks down large bubbles. If you don't have a steamer, heat the milk gently in a saucepan and whisk vigorously until frothy. It won't be as fine, but it still works.</p><h2>The Pour Matters</h2><p>I pour the frothed milk over the espresso in a steady stream, holding the foam back with a spoon. Then I spoon a thin layer of foam on top. This gives a beautiful separation of coffee and milk that you can stir in or sip through. The first sip is all coffee and foam, the second is the blended richness. It's a small detail that makes the experience feel intentional.</p><h2>One Trick for Extra Smoothness</h2><p>Here's a tip you won't find everywhere: after steaming, tap the milk pitcher on the counter and swirl it gently. This pops any remaining large bubbles and integrates the foam into the milk. The result is a uniform, velvety texture that coats your tongue rather than sitting on top. It takes five seconds and makes a noticeable difference.</p><p>If you're using a Moka pot, add a tiny pinch of salt to the coffee grounds before brewing. It reduces perceived bitterness and rounds out the flavor. Don't skip it.</p><h2>The Takeaway</h2><p>A smooth cafe con leche comes down to three things: a balanced ratio, milk heated to the right temperature, and a gentle pour. Make two cups—one for now, one for later. But honestly, you'll probably drink both before they cool.</p><p><em>Note: Caffeine affects everyone differently. If you're sensitive, pregnant, or managing a health condition, consult a qualified professional to determine what's right for you. Coffee is not suitable for young children.</em></p>

<h2>Frequently Asked Questions</h2>
<h3>What is the best coffee-to-milk ratio for cafe con leche?</h3>
<p>I use a 1:3 ratio of coffee to milk. For a double shot (about 2 oz of espresso), I use 6 oz of milk. This gives a balanced, smooth drink that's not too milky or too strong. Adjust to taste, but start there.</p>
<h3>Can I make cafe con leche without an espresso machine?</h3>
<p>Yes. A Moka pot is a great substitute. Brew it strong, using a fine grind, and stop the brew just as it starts to sputter to avoid bitterness. The coffee won't have the same crema, but it will still be rich and smooth.</p>
<h3>Why is my cafe con leche sometimes bitter?</h3>
<p>Bitterness usually comes from over-extracted coffee or overheated milk. Keep your brew time short (25-30 seconds for espresso) and don't let milk go above 160°F. Also, use fresh, medium-roast beans for a smoother flavor.</p>


<!--WPRM Recipe 677-->
<div class="wprm-fallback-recipe">
	<h2 class="wprm-fallback-recipe-name">Cafe con Leche</h2>
	<img class="wprm-fallback-recipe-image" src="https://asipofcoffe.com/wp-content/uploads/2026/08/cafe-con-leche-so-smooth-you-ll-make-two-150x150.webp"/>	<p class="wprm-fallback-recipe-summary">
		A velvety, smooth cafe con leche made with a double shot of espresso and gently steamed milk at a precise ratio for a perfectly balanced cup.	</p>
	<div class="wprm-fallback-recipe-equipment">
		<ul><li>espresso machine or Moka pot</li><li>milk frother or steam wand</li><li>thermometer</li><li>2 small cups or demitasse glasses</li></ul>	</div>
	<div class="wprm-fallback-recipe-ingredients">
		<ul><li>2 shots (about 2 oz total freshly brewed espresso or strong Moka pot coffee)</li><li>1 1/2 cups whole milk (or oat milk for dairy-free)</li><li>1 teaspoon sugar (optional, to taste)</li></ul>	</div>
	<div class="wprm-fallback-recipe-instructions">
		<ol><li>Brew your espresso or Moka pot coffee. Aim for a 1:2 coffee-to-water ratio for a concentrated shot.</li><li>While the coffee brews, gently heat the milk in a small saucepan over medium-low heat, stirring occasionally, until it reaches 150°F (65°C). Do not let it boil.</li><li>Froth the milk until it has a silky microfoam—small, fine bubbles that integrate smoothly into the milk. Avoid large, stiff foam.</li><li>Divide the espresso evenly between two small cups.</li><li>Pour the frothed milk over the espresso in a steady stream, holding back the foam with a spoon. Then spoon a thin layer of foam on top.</li><li>Stir gently to combine the coffee and milk, or serve as-is for a layered effect.</li><li>Add sugar to taste, if desired. Serve immediately.</li></ol>	</div>
	<div class="wprm-fallback-recipe-notes">
		<p>For the smoothest texture, use whole milk—its fat content creates a richer mouthfeel. If using a Moka pot, brew on low heat to avoid bitterness. This drink is best enjoyed fresh; do not reheat. Caffeine content varies; adjust to your tolerance.</p>
	</div>
	<div class="wprm-fallback-recipe-meta">
		<div class="wprm-fallback-recipe-meta-course">Beverage</div><div class="wprm-fallback-recipe-meta-cuisine">American</div>	</div>
</div>
<!--End WPRM Recipe-->